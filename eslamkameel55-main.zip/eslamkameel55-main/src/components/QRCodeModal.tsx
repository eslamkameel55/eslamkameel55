import { QRCodeSVG } from "qrcode.react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Share2, Copy, Check } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface QRCodeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const QRCodeModal = ({ open, onOpenChange }: QRCodeModalProps) => {
  const [copied, setCopied] = useState(false);
  const shareUrl = window.location.href;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: "خنفر نت - للاتصالات اللاسلكية",
        text: "انضم لشبكة خنفر نت للإنترنت السريع!",
        url: shareUrl,
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm mx-auto rounded-2xl border-0 shadow-card">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold text-foreground">
            شارك مع أصدقائك
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center gap-6 py-4">
          {/* QR Code Container */}
          <div className="relative p-4 bg-card rounded-2xl shadow-soft">
            <div className="absolute inset-0 gradient-header rounded-2xl opacity-30"></div>
            <div className="relative bg-white p-4 rounded-xl">
              <QRCodeSVG
                value={shareUrl}
                size={180}
                level="H"
                includeMargin={false}
                fgColor="#1e293b"
                bgColor="#ffffff"
              />
            </div>
          </div>

          {/* Network Name */}
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gradient mb-1">خنفر نت</h3>
            <p className="text-sm text-muted-foreground">امسح الكود للانضمام للشبكة</p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 w-full">
            <Button
              onClick={handleCopy}
              variant="outline"
              className="flex-1 h-12 rounded-xl border-2 border-border hover:border-primary/50 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-5 h-5 ml-2 text-primary" />
                  <span>تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-5 h-5 ml-2" />
                  <span>نسخ الرابط</span>
                </>
              )}
            </Button>

            <Button
              onClick={handleShare}
              className="flex-1 h-12 rounded-xl gradient-primary shadow-button"
            >
              <Share2 className="w-5 h-5 ml-2" />
              <span>مشاركة</span>
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRCodeModal;
