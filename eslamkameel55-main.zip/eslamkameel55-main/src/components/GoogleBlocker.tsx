import { useState } from "react";
import { Globe } from "lucide-react";
import { Switch } from "@/components/ui/switch";

const GoogleBlocker = () => {
  const [isBlocked, setIsBlocked] = useState(false);

  return (
    <div className="bg-card rounded-2xl p-4 shadow-card flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`transition-colors ${isBlocked ? "text-destructive" : "text-muted-foreground"}`}>
          <span className="text-sm font-medium">الحالة</span>
          <p className="text-xs">{isBlocked ? "مُفعّل" : "مُلغى"}</p>
        </div>
        <Switch
          checked={isBlocked}
          onCheckedChange={setIsBlocked}
          className="data-[state=checked]:bg-destructive"
        />
      </div>
      <div className="flex items-center gap-3">
        <div className="text-left">
          <h3 className="font-bold text-foreground">إيقاف تحديثات جوجل</h3>
          <p className="text-sm text-muted-foreground">منع التحديثات التلقائية</p>
        </div>
        <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
          isBlocked ? "bg-destructive/10" : "bg-teal/10"
        }`}>
          <Globe className={`w-6 h-6 ${isBlocked ? "text-destructive" : "text-teal"}`} />
        </div>
      </div>
    </div>
  );
};

export default GoogleBlocker;
