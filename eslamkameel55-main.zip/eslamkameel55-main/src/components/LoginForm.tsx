import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const LoginForm = () => {
  const [cardNumber, setCardNumber] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // MikroTik login logic would go here
    console.log("Login with card:", cardNumber);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Card Input */}
      <div className="bg-card rounded-2xl shadow-card overflow-hidden">
        <Input
          type="text"
          placeholder="أدخل رقم الكرت هنا"
          value={cardNumber}
          onChange={(e) => setCardNumber(e.target.value)}
          className="border-0 h-14 text-center text-lg bg-transparent placeholder:text-muted-foreground focus-visible:ring-0"
        />
      </div>

      {/* Login Button */}
      <Button
        type="submit"
        className="w-full h-14 text-lg font-bold rounded-2xl gradient-primary shadow-button hover:opacity-90 transition-opacity"
      >
        دخول الإنترنت
      </Button>
    </form>
  );
};

export default LoginForm;
