import { useState } from "react";
import { MapPin, QrCode, CreditCard } from "lucide-react";
import QRCodeModal from "./QRCodeModal";

const FooterActions = () => {
  const [qrModalOpen, setQrModalOpen] = useState(false);

  const footerActions = [
    {
      icon: CreditCard,
      label: "أسعار الكروت",
      color: "text-pink",
      onClick: () => {},
    },
    {
      icon: QrCode,
      label: "QR CODE",
      color: "text-purple",
      onClick: () => setQrModalOpen(true),
    },
    {
      icon: MapPin,
      label: "أماكن البيع",
      color: "text-orange",
      onClick: () => {},
    },
  ];

  return (
    <>
      <div className="grid grid-cols-3 gap-3">
        {footerActions.map((action, index) => (
          <button
            key={index}
            onClick={action.onClick}
            className="bg-card rounded-2xl p-4 shadow-card flex flex-col items-center gap-2 hover:scale-105 transition-transform duration-200"
          >
            <action.icon className={`w-6 h-6 ${action.color}`} />
            <span className="text-xs font-medium text-foreground">{action.label}</span>
          </button>
        ))}
      </div>

      <QRCodeModal open={qrModalOpen} onOpenChange={setQrModalOpen} />
    </>
  );
};

export default FooterActions;
