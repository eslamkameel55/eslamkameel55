import { Info, MessageSquare, Phone } from "lucide-react";

const actions = [
  {
    icon: Info,
    label: "معلومات",
    color: "bg-teal",
  },
  {
    icon: MessageSquare,
    label: "واتساب",
    color: "bg-purple",
  },
  {
    icon: Phone,
    label: "شات",
    color: "bg-pink",
  },
];

const QuickActions = () => {
  return (
    <div className="grid grid-cols-3 gap-3">
      {actions.map((action, index) => (
        <button
          key={index}
          className="bg-card rounded-2xl p-4 shadow-card flex flex-col items-center gap-2 hover:scale-105 transition-transform duration-200"
        >
          <div className={`w-12 h-12 ${action.color} rounded-full flex items-center justify-center`}>
            <action.icon className="w-6 h-6 text-white" />
          </div>
          <span className="text-sm font-medium text-foreground">{action.label}</span>
        </button>
      ))}
    </div>
  );
};

export default QuickActions;
