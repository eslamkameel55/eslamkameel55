import { Wifi } from "lucide-react";

const HeroHeader = () => {
  return (
    <div className="relative overflow-hidden rounded-2xl gradient-header p-6 shadow-card">
      {/* Live Badge */}
      <div className="absolute top-4 right-4 flex items-center gap-2 bg-card/80 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-soft">
        <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
        <span className="text-sm font-medium text-foreground">مباشر</span>
      </div>

      {/* Signal Bars */}
      <div className="absolute top-4 left-4 flex items-end gap-0.5">
        <div className="w-1.5 h-3 bg-primary/60 rounded-sm"></div>
        <div className="w-1.5 h-4 bg-primary/70 rounded-sm"></div>
        <div className="w-1.5 h-5 bg-primary/80 rounded-sm"></div>
        <div className="w-1.5 h-6 bg-primary rounded-sm"></div>
      </div>

      {/* Decorative Dots */}
      <div className="absolute top-1/3 right-8 w-2 h-2 bg-pink rounded-full opacity-60"></div>
      <div className="absolute bottom-1/3 left-12 w-1.5 h-1.5 bg-orange rounded-full opacity-60"></div>

      {/* WiFi Icon */}
      <div className="flex justify-center mb-4">
        <div className="relative">
          <div className="w-20 h-20 bg-card rounded-full flex items-center justify-center shadow-soft animate-float">
            <Wifi className="w-10 h-10 text-cyan animate-wifi" />
          </div>
          <div className="absolute inset-0 w-20 h-20 bg-cyan/20 rounded-full animate-ping"></div>
        </div>
      </div>

      {/* Subtitle Badge */}
      <div className="flex justify-center mb-3">
        <div className="bg-card/60 backdrop-blur-sm px-4 py-1.5 rounded-full border border-primary/20">
          <span className="text-sm text-muted-foreground">شبكة لاسلكية متطورة</span>
        </div>
      </div>

      {/* Main Title */}
      <h1 className="text-4xl font-extrabold text-center mb-2 text-gradient">
        خنفر نت
      </h1>

      {/* Company Badge */}
      <div className="flex justify-center mb-4">
        <div className="bg-card/80 backdrop-blur-sm px-5 py-2 rounded-full flex items-center gap-2 shadow-soft">
          <span className="text-primary">✦</span>
          <span className="text-sm font-medium text-foreground">للاتصالات اللاسلكية</span>
          <Wifi className="w-4 h-4 text-cyan" />
        </div>
      </div>

      {/* Features Line */}
      <div className="text-center">
        <span className="text-sm text-muted-foreground">
          ✨ اتصال سريع • خدمة مميزة • ثقة متجددة ✨
        </span>
      </div>
    </div>
  );
};

export default HeroHeader;
