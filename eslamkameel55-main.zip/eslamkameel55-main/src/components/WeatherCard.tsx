import { Sun } from "lucide-react";

const WeatherCard = () => {
  return (
    <div className="bg-card rounded-2xl p-4 shadow-card flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-blue/10 rounded-full flex items-center justify-center">
          <Sun className="w-6 h-6 text-blue" />
        </div>
        <span className="text-2xl font-bold text-foreground">20°C</span>
      </div>
      <div className="text-left">
        <p className="text-lg font-semibold text-foreground">الطقس اليوم :</p>
        <p className="text-muted-foreground">صافي</p>
      </div>
    </div>
  );
};

export default WeatherCard;
