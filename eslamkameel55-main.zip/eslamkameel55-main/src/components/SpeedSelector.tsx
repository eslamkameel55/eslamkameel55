import { useState } from "react";
import { Zap, Check } from "lucide-react";

const speeds = [
  { id: 1, name: "سرعة اقتصادية", emoji: "🐌", value: "1mbps" },
  { id: 2, name: "سرعة متوسطة", emoji: "🚶", value: "2mbps" },
  { id: 3, name: "سرعة عالية", emoji: "🚀", value: "5mbps" },
  { id: 4, name: "سرعة فائقة", emoji: "⚡", value: "10mbps" },
];

const SpeedSelector = () => {
  const [selectedSpeed, setSelectedSpeed] = useState<number | null>(null);

  return (
    <div className="bg-card rounded-2xl p-5 shadow-card">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
            <Zap className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">اختبار سرعة الإنترنت</h3>
            <p className="text-sm text-muted-foreground">اختر السرعة المناسبة لك</p>
          </div>
        </div>
        <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
          <Check className="w-5 h-5 text-white" />
        </div>
      </div>

      {/* Speed Grid */}
      <div className="grid grid-cols-2 gap-3">
        {speeds.map((speed) => (
          <button
            key={speed.id}
            onClick={() => setSelectedSpeed(speed.id)}
            className={`
              p-3 rounded-xl border-2 transition-all duration-200
              ${selectedSpeed === speed.id
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50 bg-secondary/50"
              }
            `}
          >
            <span className="text-lg ml-2">{speed.emoji}</span>
            <span className="text-sm font-medium text-foreground">{speed.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SpeedSelector;
