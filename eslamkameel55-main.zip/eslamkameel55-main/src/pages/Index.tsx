import HeroHeader from "@/components/HeroHeader";
import WeatherCard from "@/components/WeatherCard";
import QuickActions from "@/components/QuickActions";
import SpeedSelector from "@/components/SpeedSelector";
import LoginForm from "@/components/LoginForm";
import GoogleBlocker from "@/components/GoogleBlocker";
import FooterActions from "@/components/FooterActions";

const Index = () => {
  return (
    <div className="min-h-screen bg-background py-4 px-4">
      <div className="max-w-md mx-auto space-y-4">
        {/* Hero Header */}
        <HeroHeader />

        {/* Weather Card */}
        <WeatherCard />

        {/* Quick Actions */}
        <QuickActions />

        {/* Speed Selector */}
        <SpeedSelector />

        {/* Login Form */}
        <LoginForm />

        {/* Google Blocker */}
        <GoogleBlocker />

        {/* Footer Actions */}
        <FooterActions />
      </div>
    </div>
  );
};

export default Index;
