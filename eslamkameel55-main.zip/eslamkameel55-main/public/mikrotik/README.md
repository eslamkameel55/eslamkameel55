# ملفات MikroTik Hotspot

## الملفات المتوفرة:
- `login.html` - صفحة تسجيل الدخول الرئيسية
- `status.html` - صفحة حالة الاتصال
- `error.html` - صفحة الخطأ
- `logout.html` - صفحة تسجيل الخروج

## طريقة التثبيت:

### 1. تحميل الملفات
حمّل جميع ملفات HTML من مجلد `public/mikrotik/`

### 2. رفع الملفات على الروتر
استخدم Winbox أو FTP لرفع الملفات:
```
/file print
```
ارفع الملفات إلى مجلد `hotspot` على الروتر

### 3. إعداد Walled Garden
أضف المواقع المطلوبة:
```bash
/ip hotspot walled-garden
add dst-host=fonts.googleapis.com action=allow
add dst-host=fonts.gstatic.com action=allow
```

### 4. اختبار الصفحة
اتصل بشبكة الـ Hotspot وتأكد من ظهور الصفحة

## المتغيرات المستخدمة:
- `$(link-login-only)` - رابط تسجيل الدخول
- `$(link-login)` - رابط صفحة الدخول
- `$(link-logout)` - رابط تسجيل الخروج
- `$(link-orig)` - الصفحة الأصلية
- `$(ip)` - عنوان IP
- `$(mac)` - عنوان MAC
- `$(error)` - رسالة الخطأ
- `$(session-time-left)` - الوقت المتبقي
- `$(bytes-left)` - البيانات المتبقية

## التخصيص:
- غيّر "خنفر نت" باسم شبكتك
- عدّل رقم الواتساب في login.html
- أضف شعارك الخاص
